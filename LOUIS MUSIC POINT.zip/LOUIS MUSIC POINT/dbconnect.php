<?php
$connect=mysql_connect("localhost","root","");
mysql_select_db("music_Point",$connect);
?>

